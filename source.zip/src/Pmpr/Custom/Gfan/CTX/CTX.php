<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705174c85a83             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Gfan\Container; class CTX extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x74\141\x78\157\x6e\157\x6d\x79\x5f\x73\151\x6e\147\x6c\145\x5f\x76\141\154\165\x65\x5f\155\x6f\144\x69\x66\171\x5f\x69\x74\145\155\163", [$this, "\x73\143\157\141\171\141\155\165\x79\161\147\x6b\x63\141\155\x67"]); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) : array { $oammesyieqmwuwyi[] = Constants::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = Constants::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
