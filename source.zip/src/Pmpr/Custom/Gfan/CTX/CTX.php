<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e77a5b7b5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Gfan\Container; class CTX extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x74\141\170\157\156\x6f\x6d\171\137\163\151\x6e\x67\x6c\x65\137\x76\141\x6c\x75\145\x5f\155\x6f\x64\x69\146\x79\x5f\151\x74\x65\155\163", [$this, "\x73\143\x6f\141\171\x61\x6d\x75\x79\x71\147\x6b\x63\x61\x6d\147"]); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) : array { $oammesyieqmwuwyi[] = Constants::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = Constants::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
