<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebed40893             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Gfan\Container; class CTX extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x74\x61\170\157\x6e\157\155\x79\x5f\x73\x69\x6e\x67\x6c\145\x5f\166\141\x6c\x75\x65\x5f\155\x6f\x64\x69\146\x79\137\151\x74\145\x6d\163", [$this, "\163\x63\157\x61\171\x61\x6d\165\171\x71\147\153\143\x61\x6d\x67"]); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) : array { $oammesyieqmwuwyi[] = Constants::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = Constants::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
