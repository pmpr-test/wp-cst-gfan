<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae86384890             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Gfan\Container; class CTX extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x74\141\170\x6f\156\x6f\x6d\171\x5f\163\x69\156\x67\154\x65\x5f\x76\x61\154\x75\x65\137\x6d\x6f\x64\x69\x66\171\x5f\x69\x74\145\x6d\x73", [$this, "\163\x63\157\141\x79\x61\x6d\165\x79\x71\x67\x6b\143\x61\155\147"]); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) : array { $oammesyieqmwuwyi[] = Constants::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = Constants::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
