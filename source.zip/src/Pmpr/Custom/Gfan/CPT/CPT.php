<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e77a5b7b5             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\CPT; use Pmpr\Custom\Gfan\Container; class CPT extends Container { public function mameiwsayuyquoeq() { FarmTour::symcgieuakksimmu(); } }
