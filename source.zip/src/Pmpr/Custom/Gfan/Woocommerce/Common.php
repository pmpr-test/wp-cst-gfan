<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705174c85a83             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\Woocommerce; use Pmpr\Custom\Gfan\Container; abstract class Common extends Container { }
