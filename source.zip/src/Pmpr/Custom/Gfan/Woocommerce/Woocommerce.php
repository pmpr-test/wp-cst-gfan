<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705174c85a83             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\Woocommerce; class Woocommerce extends Common { public function mameiwsayuyquoeq() { Invoice::symcgieuakksimmu(); } }
