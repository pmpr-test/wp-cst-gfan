<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebed40893             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Gfan\Woocommerce; class Woocommerce extends Common { public function mameiwsayuyquoeq() { Invoice::symcgieuakksimmu(); } }
